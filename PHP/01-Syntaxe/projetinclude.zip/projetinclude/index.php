<?php
require_once("partials/_config.php");
require_once("partials/_functions.php");



/////////////////////////////////////
// Le code PHP propre à chaque page
////////////////////////////////////




require_once("partials/_header.php"); // Début des affichages
require_once("partials/_nav.php"); // Certaines fonctions PHP ne vont plus fonctionner convenablement
?>
<!-- Begin page content -->
<main class="flex-shrink-0">
    <div class="container">
        <h1 class="mt-5">Bienvenue sur notre site eshop</h1>
       
        <p>Achetez nos beaux produits</p>
    </div>
</main>

<?php
require_once("partials/_footer.php");
