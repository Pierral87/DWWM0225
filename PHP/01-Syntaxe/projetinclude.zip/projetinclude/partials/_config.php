<?php

// Ici, un fichier config
// Ce fichier va contenir des informations d'initialisation de configuration nécessaires au bon fonctionnement de notre application

// Par exemple 


// Initialisation de la connexion à la Base De Données

// Lancement de la session utilisateur

// Initialisation des constantes
