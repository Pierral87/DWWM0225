<?php 

// Ici, mes fonctions 

function dump($var) {
    echo "<pre>";
    var_dump($var);
    echo "</pre>";
}

