 <footer class="footer mt-auto py-3 bg-body-tertiary fixed-bottom">
        <div class="container"> <span class="text-body-secondary">Copyright Pierra 2025 &copy;</span> </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
</body>

</html>